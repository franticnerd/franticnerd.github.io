package algo;

import graph.Graph;
import graph.NodeTransition;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class Squeeze extends TopKSearch {
	
	Double [] mScore = null;
	Double [] mPreviousScore = null;
	double mErrorBound;
	double mThreshold = -1; // the k-th lower bound as the threshold
	int mTotalIter = 0;

	public Squeeze(Graph graph) {
		super(graph);
	}
	
	public List<Integer> search(int queryId, int K, double c) {
		
		long start = System.currentTimeMillis();
		List<Integer> result = initialize(K);
		while (result.size() > K) {
			if(mErrorBound <= 1E-8)
				break;
			swap();
			update(queryId, c);
            mTotalIter += 1;
			mErrorBound *= (1-c);
			result = prune(result, K);
		}
		long end = System.currentTimeMillis();
		mElapseTime = (end - start) / 1000.0;


//        for(Double value: mScore)
//            System.out.println(value);
//
//        for(Integer i : result)
//            System.out.println(mScore[i]);

		return result;

	}
	
	public List<Integer> initialize(int K) {
        mErrorBound = 1.0;
        mThreshold = -1.0;
        mTotalIter = 0;
		mScore = new Double [mGraphSize];
		mPreviousScore = new Double [mGraphSize];
		for(int i=0; i<mGraphSize; i++)
			mScore[i] = mPreviousScore[i] = 0.0;
		
		List<Integer> result = new ArrayList<Integer>();
		for(int i=0; i<mGraphSize; i++) {
			result.add( i );
		}
		return result;
	}
	
	public void update(int queryId, double c) {
		for(int i=0; i<mGraphSize; i++)	{
			List<NodeTransition> outNeighbors = mGraph.getOutgoingTransitions(i);
			double score = 0;
			for(NodeTransition nt: outNeighbors) {
				double probability = nt.getProbability();
				int neighborId = nt.getNodeId();
				score += mPreviousScore[neighborId] * probability;
			}
			score *= (1 - c);
			// the query node itself
			if( i == queryId )	{
				score += c;
			}
			mScore[i] = score;
		}
	}
	
	//swap previous and current socialInfluenceArray, preparing for next iteration
	private void swap()	{
		Double [] tmp = mPreviousScore;
		mPreviousScore = mScore;
		mScore = tmp;
	}
	
	public List<Integer> prune(List<Integer> nodeList, int K) {
		mThreshold = select(K);
		List<Integer> result = new ArrayList<Integer>();
		for(Integer nodeId: nodeList) {
            double weight = mGraph.getNode(nodeId).getWeight();
			if( weight * (mScore[nodeId] + mErrorBound) > mThreshold)
				result.add( nodeId );
		}
		return result;
	}
	
	// select the K-th largest lower bound, score * weight
	private double select(int K) {
		double previousThreshold = mThreshold; // the threshold will increase monotonically

        // min-heap, ascending order of lower bound
        PriorityQueue<Double> minHeap = new PriorityQueue<Double>(10,
                new Comparator<Double>() {
                    public int compare(Double e1, Double e2) {
                        if (e1.compareTo(e2) < 0)
                            return -1;
                        else if (e1.compareTo(e2) == 0)
                            return 0;
                        else
                            return 1;
                    }
                });

		for(int i=0; i<mGraphSize; i++) {
            double value = mGraph.getNode(i).getWeight() * mScore[i];
			if(value >= previousThreshold) {
				if(minHeap.size() < K)
					minHeap.offer( value );
				else if( value > minHeap.peek() ) {
					minHeap.poll();
					minHeap.offer( value );
				}
			}
		}
		return minHeap.peek();
	}

    public int getNumOfIter() {
        return mTotalIter;
    }


    public static void main(String[] args) throws Exception {
        String nodeFile = "./nodes.txt";
        String edgeFile = "./edges.txt";
        Graph graph = new Graph();
        graph.loadNodes(nodeFile);
        graph.loadEdges(edgeFile, false); // directed graph
        Squeeze squeeze = new Squeeze(graph);
        System.out.println(squeeze.search(100, 5, 0.1));
    }


}