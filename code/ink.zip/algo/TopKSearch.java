package algo;

import graph.Graph;

import java.util.List;

public abstract class TopKSearch {
	
	Graph mGraph;
	int mGraphSize; // number of nodes in the graph
	double mElapseTime;
	
	public TopKSearch(Graph graph) {
		this.mGraph = graph;
		this.mGraphSize = graph.getNodeCnt();
	}
	
	// queryId: query node, K: number of results, c: restart probability
	public abstract List<Integer> search(int queryId, int K, double c);
	
	public double getElapseTime()	{
		return mElapseTime;
	}
}