package algo;

import graph.Graph;
import graph.NodeTransition;

import java.util.*;


public class Ripple extends TopKSearch {

    int S = 3; // the number of nodes for expansion in each round
    int T = 3; // the number of iterations after expansion in each round

    Double[] mScore = null;
    Double[] mPreviousScore = null;
    Set<Integer> mVicinityNodes = null;
    Set<Integer> mBoundaryNodes = null;

    double mOutsideUB = 1.0; // upper bound for nodes outside the neighborhood
    double mInsideUB = 1.0; // upper bound for nodes inside the neighborhood

    int mTotalIterationNum = 0; // to record how many iterations have been performed

    double mThreshold = -1; // the k-th lower bound as the threshold
    double mDelta = 0; // the change of score after the first iteration
    double mConstant = 0; // (1-c)^T, pre-store to avoid repeatedly computing

    Set<Integer> mCandidates; // the ids of the nodes that have not been pruned

    public Ripple(Graph graph, int numExpansionNode, int numExpansionIter) {
        super(graph);
        this.S = numExpansionNode;
        this.T = numExpansionIter;
    }

    public List<Integer> search(int queryId, int K, double c) {

        initialize(queryId, c);
        long start = System.currentTimeMillis();
        while (true) {

            if( (mCandidates.size()<=K && mOutsideUB <= mThreshold) || mTotalIterationNum >= 1000)
                break;

            expand();
            update(queryId, c);
            calcBounds(c);
            prune(K);

            mTotalIterationNum ++;
        }
        long end = System.currentTimeMillis();
        mElapseTime = (end - start) / 1000.0;
        return new ArrayList<Integer>( mCandidates );
    }

    private void initialize(int queryId, double c) {
        // initialize the constant
        mConstant = Math.pow(1 - c, T);
        mThreshold = -1; // the k-th lower bound as the threshold
        mDelta = 0; // the change of score after the first iteration
        mTotalIterationNum = 0;

        // initialize the bounds
        mInsideUB = mOutsideUB = 1.0;

        // initialize the scores
        mScore = new Double[mGraphSize];
        mPreviousScore = new Double[mGraphSize];
        for (int i = 0; i < mGraphSize; i++)
            mScore[i] = mPreviousScore[i] = 0.0;

        // initialize boundary and neighborhood
        mVicinityNodes = new HashSet<Integer>();
        mBoundaryNodes = new HashSet<Integer>();

        mVicinityNodes.add(queryId);
        mBoundaryNodes.add(queryId);

        // initialize the result set
        mCandidates = new HashSet<Integer>();
        mCandidates.add(queryId);
    }


    private void expand() {
        // expand S boundary nodes with the largest score
        List<Integer> toExpandBoundaryNodes = findToExpandBoundaryNodes();
        for (Integer boundaryNodeId : toExpandBoundaryNodes) {
            mBoundaryNodes.remove(boundaryNodeId);
            ArrayList<Integer> inNeighbors = mGraph.getInNeighbors(boundaryNodeId);
            mVicinityNodes.addAll(inNeighbors); // update the vicinity node set
            mBoundaryNodes.addAll(inNeighbors); // update the boundary node set, false positives will be removed later
            mCandidates.addAll(inNeighbors);
        }

        // update the boundary node set
        Iterator<Integer> iterator = mBoundaryNodes.iterator();
        while (iterator.hasNext()) {
            Integer boundaryNodeId = iterator.next();
            if (!isBoundary(boundaryNodeId)) {
                iterator.remove(); // remove false positive
            }
        }
    }

    // find the S nodes that need to be expanded
    private List<Integer> findToExpandBoundaryNodes() {
        List<NodeScore> nodeScores = new ArrayList<NodeScore>();
        for (Integer boundaryNodeId : mBoundaryNodes) {
            nodeScores.add( new NodeScore(boundaryNodeId, mScore[boundaryNodeId]) );
        }
        Collections.sort(nodeScores, new Comparator<NodeScore>() {
            public int compare(NodeScore u1 , NodeScore u2) {
                if(u1.getScore()- u2.getScore() > 0) // descending order
                    return -1;
                else if (u1.getScore()- u2.getScore() == 0)
                    return 0;
                else
                    return 1;
            }
        });
        int resultSize = nodeScores.size() >= S ? S : nodeScores.size();
        List<Integer> result = new ArrayList<Integer>();
        for(int i=0; i<resultSize; i++) {
            result.add( nodeScores.get(i).getNodeId() );
        }
        return result;
    }

    private boolean isBoundary(int id) {
        List<Integer> inNeighbors = mGraph.getInNeighbors(id);
        for (Integer i : inNeighbors) {
            if (!mVicinityNodes.contains(i))
                return true;
        }
        return false;
    }


    // swap previous and current score arrays, preparing for update
    private void swap() {
        Double[] tmp = mPreviousScore;
        mPreviousScore = mScore;
        mScore = tmp;
    }


    // update the scores for nodes in the vicinity
    public void update(int queryId, double c) {
        for (int i = 1; i <= T; i++) {
            swap(); // swap previous and current score arrays, preparing for update
            for (Integer nodeId : mVicinityNodes) {
                List<NodeTransition> outTransitions = mGraph.getOutgoingTransitions(nodeId);
                double score = 0;
                for (NodeTransition nt : outTransitions) {
                    double probability = nt.getProbability();
                    int neighborId = nt.getNodeId();
                    score += mPreviousScore[neighborId] * probability;
                }
                score *= (1 - c);
                // the query node itself
                if (nodeId == queryId) {
                    score += c;
                }
                mScore[nodeId] = score;
            }

            if (i == 1) {
                findDelta();
            }
        }
    }

    private void findDelta() {
        mDelta = 0;
        for (Integer nodeId : mVicinityNodes)
            if (mScore[nodeId] - mPreviousScore[nodeId] > mDelta)
                mDelta = mScore[nodeId] - mPreviousScore[nodeId];
    }


    private void calcBounds(double c) {
        // calc maximum boundary node score
        double maxBoundaryScore = 0;
        for (Integer i : mBoundaryNodes)
            if (mScore[i] > maxBoundaryScore)
                maxBoundaryScore = mScore[i];

        mOutsideUB = (1 - c) * (maxBoundaryScore + mConstant * mDelta / c) / (2 * c - c * c);
        mInsideUB = (1 - c) * (1 - c) / (2 * c - c * c) * maxBoundaryScore + mConstant * mDelta / (2 * c * c - c * c * c);
    }


    private void prune(int K) {
        mThreshold = select(K);
        // update the boundary node set
        Iterator<Integer> iterator = mCandidates.iterator();
        while (iterator.hasNext()) {
            Integer nodeId = iterator.next();
            double weight = mGraph.getNode(nodeId).getWeight();
            if (weight * (mScore[nodeId] + mInsideUB) < mThreshold)
                iterator.remove();
        }
    }

    // select the K-th largest lower bound from the vicinity nodes
    private double select(int K) {
        if (mVicinityNodes.size() < K)
            return 0;
        double previousThreshold = mThreshold; // the threshold will increase monotonically

        // min-heap, ascending order of lower bound
        PriorityQueue<Double> minHeap = new PriorityQueue<Double>(10,
                new Comparator<Double>() {
                    public int compare(Double e1, Double e2) {
                        if (e1.compareTo(e2) < 0)
                            return -1;
                        else if (e1.compareTo(e2) == 0)
                            return 0;
                        else
                            return 1;
                    }
                });

        for (Integer nodeId : mVicinityNodes) {
            double value = mScore[nodeId] * mGraph.getNode(nodeId).getWeight();
            if (value >= previousThreshold) {
                if (minHeap.size() < K)
                    minHeap.offer(value);
                else if (value > minHeap.peek()) {
                    minHeap.poll();
                    minHeap.offer(value);
                }
            }
        }
        return minHeap.peek();
    }

    public int getNumOfIter() {
        return mTotalIterationNum;
    }

    private class NodeScore {
        int nodeId;
        double score;
        public NodeScore(int nodeId, double score) {
            this.nodeId = nodeId;
            this.score = score;
        }
        public int getNodeId() {
            return nodeId;
        }
        public double getScore() {
            return score;
        }

    }

    public static void main(String[] args) throws Exception {
        String nodeFile = "./nodes.txt";
        String edgeFile = "./edges.txt";
        Graph graph = new Graph();
        graph.loadNodes(nodeFile);
        graph.loadEdges(edgeFile, false); // directed graph
        Ripple squeeze = new Ripple(graph, 1, 1);
        System.out.println(squeeze.search(100, 5, 0.1));
    }

}